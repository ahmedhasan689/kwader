<!-- Title -->
<title> Valex -  Premium dashboard ui bootstrap rwd admin html5 template </title>
<!-- Favicon -->
<link rel="icon" href="{{ asset('Dashboard_Assets/img/brand/favicon.png') }}" type="image/x-icon"/>
<!-- Icons css -->
<link href="{{ asset('Dashboard_Assets/css/icons.css') }}" rel="stylesheet">
<!--  Custom Scroll bar-->
<link href="{{ asset('Dashboard_Assets/plugins/mscrollbar/jquery.mCustomScrollbar.css') }}" rel="stylesheet"/>
<!--  Sidebar css -->
<link href="{{ asset('Dashboard_Assets/plugins/sidebar/sidebar.css') }}" rel="stylesheet">
<!-- Sidemenu css -->
<link rel="stylesheet" href="{{ asset('Dashboard_Assets/css-rtl/sidemenu.css') }}">

@yield('css')

<!--- Style css -->
<link href="{{ asset('Dashboard_Assets/css-rtl/style.css') }}" rel="stylesheet">
<!--- Dark-mode css -->
<link href="{{ asset('Dashboard_Assets/css-rtl/style-dark.css') }}" rel="stylesheet">
<!---Skinmodes css-->
<link href="{{ asset('Dashboard_Assets/css-rtl/skin-modes.css') }}" rel="stylesheet">
@toastr_css
