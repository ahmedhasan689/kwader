
<!-- Back-to-top -->
<a href="#top" id="back-to-top"><i class="las la-angle-double-up"></i></a>

<script src="https://kit.fontawesome.com/5427831588.js" crossorigin="anonymous"></script>
<!-- JQuery min js -->
<script src="<?php echo e(asset('Dashboard_Assets/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap Bundle js -->
<script src="<?php echo e(asset('Dashboard_Assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Ionicons js -->
<script src="<?php echo e(asset('Dashboard_Assets/plugins/ionicons/ionicons.js')); ?>"></script>
<!-- Moment js -->
<script src="<?php echo e(asset('Dashboard_Assets/plugins/moment/moment.js')); ?>"></script>

<!-- Rating js-->
<script src="<?php echo e(asset('Dashboard_Assets/plugins/rating/jquery.rating-stars.js')); ?>"></script>
<script src="<?php echo e(asset('Dashboard_Assets/plugins/rating/jquery.barrating.js')); ?>"></script>

<!--Internal  Perfect-scrollbar js -->
<script src="<?php echo e(asset('Dashboard_Assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('Dashboard_Assets/plugins/perfect-scrollbar/p-scroll.js')); ?>"></script>
<!--Internal Sparkline js -->
<script src="<?php echo e(asset('Dashboard_Assets/plugins/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
<!-- Custom Scroll bar Js-->
<script src="<?php echo e(asset('Dashboard_Assets/plugins/mscrollbar/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<!-- right-sidebar js -->
<script src="<?php echo e(asset('Dashboard_Assets/plugins/sidebar/sidebar-rtl.js')); ?>"></script>
<script src="<?php echo e(asset('Dashboard_Assets/plugins/sidebar/sidebar-custom.js')); ?>"></script>
<!-- Eva-icons js -->
<script src="<?php echo e(asset('Dashboard_Assets/js/eva-icons.min.js')); ?>"></script>

<?php echo jquery(); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
<?php echo $__env->yieldContent('js'); ?>
<!-- Sticky js -->
<script src="<?php echo e(asset('Dashboard_Assets/js/sticky.js')); ?>"></script>
<!-- custom js -->
<script src="<?php echo e(asset('Dashboard_Assets/js/custom.js')); ?>"></script><!-- Left-menu js-->
<script src="<?php echo e(asset('Dashboard_Assets/plugins/side-menu/sidemenu.js')); ?>"></script>

<?php /**PATH E:\kwader\resources\views/layouts/footer-scripts.blade.php ENDPATH**/ ?>